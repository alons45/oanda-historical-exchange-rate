from distutils.core import setup

setup(
    name='oanda-historical-exchange-rate',
    version='0.3',
    license='GPL',
    author='Alonso',
    author_email='alons45@gmail.com',
    py_modules=['historical_rates'],
)
